#include "SmartPointer.h"

SmartPointer::SmartPointer(const SmartPointer &sptr)
{
  pointer = sptr.pointer;
  ref_cnt = sptr.ref_cnt;
  if(ref_cnt!=nullptr)
    (*ref_cnt)++;
}

void SmartPointer::assign(const SmartPointer &sptr)
{
  if (this == &sptr)
    return;
  if (pointer != nullptr)
  {
    (*ref_cnt)--;
    if (*ref_cnt == 0)
    {
      delete ref_cnt;
      delete pointer;
    }
  }

  pointer = sptr.pointer;
  ref_cnt = sptr.ref_cnt;
  if(ref_cnt!=nullptr)
    (*ref_cnt)++;
}

SmartPointer::~SmartPointer()
{
  if(pointer!=nullptr){
    (*ref_cnt)--;
    if (*ref_cnt == 0)
    {
      delete ref_cnt;
      delete pointer;
    }
    ref_cnt=nullptr;
    pointer=nullptr;
  }
}
