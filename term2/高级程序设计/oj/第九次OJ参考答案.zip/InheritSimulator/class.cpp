#include "class.h"

void Class::add_inherit_class(const Class* parent, bool is_virtual) {
    base_classes_.emplace(parent, is_virtual);
}

void Class::add_member_variable(const char* name) {
    member_variables_.emplace(name);
}