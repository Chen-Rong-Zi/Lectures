#include "MonsterLand.h"
using namespace std;
void MonsterLand::game(int n, int *num){
    //TODO 让乐园记录今天的游戏初始状态
    number = n;
    for(int i=0;i<n;++i){
        gem[i] = num[i];
    }
}
int MonsterLand::gcd(int a,int b){
    if(b==0){
        return a;
    }else{
        return gcd(b,a%b);
    }
}

int MonsterLand::quiz(){
    int result = 0;
    //TODO 计算出最后留在游戏中的小怪兽的可能的最小宝石数量
    result = gcd(gem[0],gem[1]);
    for(int i=2;i<number;++i){
        result = gcd(result,gem[i]);
    }
    return result;

}
int arr[105];
int main()
{
    int n;
    cin >> n;
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    MonsterLand s;
    s.game(n,arr);
    cout << s.quiz() << endl;
    return 0;
}