"""write your code in method"""


# 编写一个程序，接受一个假期的开始时间作为输入，然后计算从2024年3月4日距离假期还有多少天，并输出。（假设假期开始时间在2024年内）

def get_day(month, day):
    days = 0

    if month == 3:
        days = day - 4
    else:
        days += 27 + day
        if month >= 4:
            days += 0
        if month >= 5:
            days += 30
        if month >= 6:
            days += 31
        if month >= 7:
            days += 30
        if month >= 8:
            days += 31
        if month >= 9:
            days += 31
        if month >= 10:
            days += 30
        if month >= 11:
            days += 31
        if month >= 12:
            days += 30

    # print(str(days))

    return days
