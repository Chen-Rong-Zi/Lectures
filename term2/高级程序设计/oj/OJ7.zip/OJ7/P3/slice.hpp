#include <memory>
#include <cstring>
#include <iostream>

struct SliceOutOfBoundError {};

class Slice {
private:
    std::shared_ptr<int> buf;
    size_t base;
    size_t length;
    size_t capacity;

    static void free_buf(int *buf) {
        delete[] buf;
    }

    static std::shared_ptr<int> allocate_buf(size_t size) {
        return std::shared_ptr<int>(new int[size], free_buf);
    }

public:
    Slice(size_t size, int initial = 0): buf(allocate_buf(size * 2)), length(size), capacity(size * 2), base(0) {
        for(int i = 0; i < size; i++){
            buf.get()[i] = initial;
        }
    }

    Slice(const Slice &other) = default;
    
    static Slice copy_from(const Slice &other) {
        auto new_slice = Slice(other);
        new_slice.buf = allocate_buf(new_slice.capacity);
        for(int i = 0; i < new_slice.length; i++){
            new_slice.buf.get()[i] = other.buf.get()[other.base + i];
        }
        return new_slice;
    }

    void operator=(const Slice &other) {
        buf = other.buf;
        capacity = other.capacity;
        length = other.length;
        base = other.base;
    }

    void append(int x) {
        length++;
        if(length + base > capacity){
            auto old = buf;
            buf = allocate_buf(length * 2);
            for(int i = 0; i < capacity; i++){
                buf.get()[i] = old.get()[base + i];
            }
            base = 0;
            capacity = length * 2;
        }
        buf.get()[base + length - 1] = x;
    }

    Slice operator[](std::pair<size_t, size_t> range) {
        if(range.second < range.first || range.first < 0 || range.second > capacity) throw SliceOutOfBoundError();
        Slice new_slice(*this);
        new_slice.base = range.first + base;
        new_slice.length = range.second - range.first;
        return new_slice;
    }

    int& operator[](size_t pos) {
        if(pos > length) { throw SliceOutOfBoundError();
}
        return buf.get()[base+pos];
    }

    void print() {
        for (int i = 0; i < length; ++i) {
            std::cout << buf.get()[base + i] << ' ';
        }
        std::cout << '\n';
    }

    size_t len() {
        return length;
    }
    
    size_t cap() {
        return capacity;
    }
};