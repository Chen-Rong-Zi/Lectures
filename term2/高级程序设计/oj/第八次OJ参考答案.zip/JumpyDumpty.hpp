#ifndef JUMPYDUMPTY_HPP_
#define JUMPYDUMPTY_HPP_
#include <vector>

using i64 = long long;

class JumpyDumpty {
public:
    i64 operator()(std::vector<int> bombs) {
        int n = bombs.size();

        i64 ans = 0;
        i64 prev = bombs[0], cur = 0;
        int prev_shift = 0, cur_shift = 0;

        for (int i = 1; i < n; ++i) {
            cur = bombs[i];
            cur_shift = __builtin_clzll(cur) - __builtin_clzll(prev);
            if (cur_shift >= 0) {
                if ((cur << cur_shift) < prev) {
                    ++cur_shift;
                }
            } else {
                if (cur < (prev << -cur_shift)) {
                    ++cur_shift;
                }
            }
            cur_shift += prev_shift;
            cur_shift = std::max(cur_shift, 0);

            ans += cur_shift;
            prev = cur;
            prev_shift = cur_shift;
        }

        return ans;
    }
};

#endif