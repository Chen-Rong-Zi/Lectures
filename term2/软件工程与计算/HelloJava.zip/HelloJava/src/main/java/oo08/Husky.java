package oo08;

import variable_method02.Dog;

public class Husky extends Dog {
    public void bark(){ // Overriding, Same Method,
        System.out.println("oo.Husky Bark!");
    }
}
