"""write your code in method"""


def is_triangle(a, b, c):
    Max = max(a, b, c)
    Min = min(a, b, c)
    mid = a + b + c - Min - Max

    if Min + mid > Max:
        return True
    else:
        return False
