#include "farm.h"
using namespace std;

Farm::Farm(int X,int N){
	coins=X;
	totnumber=0;
	maxnumber=N;
	head=NULL;
	number[0]=number[1]=number[2]=0;
}
Farm::~Farm(){
	Monster *p=head,*q=p;
//	while(p!=NULL){
//		q=p->next;
//		int type=p->type;
//		coins+=(price[type+3]*(p->day*weight[type+3]+weight[type]));
//		delete p;
//		p=q;
//	}
	saleMonster(0,number[0]);
	saleMonster(1,number[1]);
	saleMonster(2,number[2]);
	cout<<coins<<endl;
}
int Farm::buyMonster(int type, int num){//�����ܵ�ħ������  
	if(coins >= price[type]*num && num+totnumber<=maxnumber){
		//β�巨 
		Monster *p=head,*q=head;
		while(q!=NULL){
			p=q;
			q=q->next;
		}
		coins-= price[type]*num;
		number[type]+=num;
		totnumber+=num;
		while(num--){
			Monster *m=new Monster();
			m->day=0,m->type=type;
			if(head==NULL){
				head=p=m;
			}
			else{
				p->next = m;
				p=p->next;
			}
			
		}
	}
	
	return totnumber;
}
int Farm::saleMonster(int type, int num){//������������ܽ����
	if(number[type] < num) return coins;
	number[type]-=num;
	totnumber-=num;
	int coin=0;
	Monster *p=head,*q=p;
	while(p!=NULL){
		if(p->type == type){
			coins+=price[type+3]*(p->day*weight[type+3]+weight[type]);
			if(p==head){
				head=q=p->next;
				delete p;
				p=q;
			}
			else{
				q->next = p->next;
				delete p;
				p=q->next;
			}
			num--;
			if(num==0) break;
		}
		else{
			q=p;
			p=p->next;
		}
	}
	return coins;
}
void Farm::raiseMonster(int t){//��ħ��t��
	Monster *p=head;
	while(p!=NULL){
		p->day+=t;
		p=p->next;
	}
}

//�ύ����ʱ���ע�� 
//int main(){
//    Farm farm1 = Farm(50,10);//X=50
//    cout<<farm1.buyMonster(1,1)<<endl;//1
//    cout<<farm1.buyMonster(0,2)<<endl;//3
//    farm1.raiseMonster(7);
//    cout<<farm1.saleMonster(1,1)<<endl;//56
//}//86
// 
