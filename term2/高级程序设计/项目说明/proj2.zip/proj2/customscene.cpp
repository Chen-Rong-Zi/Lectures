#include "customscene.h"
#include <QGraphicsSceneDragDropEvent>
#include <QMimeData>
#include <QListWidget>
#include <QGraphicsPixmapItem>
#include <QDebug>
#include <QGraphicsView>


CustomScene::CustomScene(QWidget* parent)
    :QGraphicsScene(parent)
{

}
