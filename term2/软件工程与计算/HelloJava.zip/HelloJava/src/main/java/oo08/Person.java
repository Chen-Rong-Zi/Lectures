package oo08;

public class Person{
    private String  name ;
    private int     birthday;

    public void getName(){
    }
    public void getAge(){
    }
}