package oo08;

public abstract class Robot{

}
