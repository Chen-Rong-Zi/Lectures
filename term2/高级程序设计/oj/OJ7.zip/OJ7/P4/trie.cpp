#include "trie.h"
#include <cstddef>
#include <memory>
#include <string>
#include <utility>

const int *Trie::Get(std::string key) const {
    if (root_ == nullptr) {
        return nullptr;
    }
    const TrieNode *iter = root_.get();
    while (!key.empty()) {
        auto next_tire = iter->children_.find(key.front());
        if (next_tire != iter->children_.end()) {
            iter = next_tire->second.get();
            key.erase(0, 1);
        } else {
            return nullptr;
        }
    }
    const auto *val_node = dynamic_cast<const TrieNodeWithValue *>(iter);
    if (val_node != nullptr) {
        return val_node->value_.get();
    }
    return nullptr;
}

Trie Trie::Put(std::string key, int value) const {
    auto root = root_ == nullptr ? std::make_shared<TrieNode>() : root_;
    Trie new_trie(root->FindValue(std::move(key), value));
    return new_trie;
}

Trie Trie::Remove(std::string key) const {
    auto root = root_ == nullptr ? std::make_shared<TrieNode>() : root_;
    auto new_root = root_->DeleteValue(std::move(key));
    return Trie(new_root);
}

std::shared_ptr<TrieNode> TrieNode::FindValue(std::string key,
                                              int value) const {
    if (key.length() == 0) {
        return std::make_shared<TrieNodeWithValue>(
            children_, std::make_shared<int>(value));
    }
    char cur_key = key.front();
    std::shared_ptr<const TrieNode> next_node;
    if (children_.find(cur_key) == children_.end()) {
        next_node = std::make_shared<TrieNode>();
    } else {
        next_node = children_.at(cur_key);
    }
    key.erase(0, 1);
    auto result = next_node->FindValue(key, value);
    if (result != next_node) {
        auto return_node = std::shared_ptr<TrieNode>(this->Clone());
        return_node->children_[cur_key] = result;
        return return_node;
    }
    return std::make_shared<TrieNode>(*this);
}

std::shared_ptr<TrieNode> TrieNode::DeleteValue(std::string key) const {
    if (key.length() == 0) {
        if (is_value_node_) {
            if (!children_.empty()) {
                return std::make_shared<TrieNode>(children_);
            }
            return {nullptr};
        }
        return std::make_shared<TrieNode>(*this);
    }
    auto cur_key = key.front();
    auto cur_children = children_;
    if (cur_children.find(cur_key) != cur_children.end()) {
        key.erase(0, 1);
        auto next_node = cur_children.at(cur_key);
        auto new_node = next_node->DeleteValue(key);
        if (next_node == new_node) {
            return std::make_shared<TrieNode>(*this);
        }
        auto new_this = this->Clone();
        if (new_node == nullptr) {
            new_this->children_.erase(cur_key);
            if (new_this->children_.empty() && !new_this->is_value_node_) {
                new_this.reset();
            }
            return {std::move(new_this)};
        }
        new_this->children_.at(cur_key) = new_node;
        return {std::move(new_this)};
    }
    return std::make_shared<TrieNode>();
}
