"""write your code in method"""


def get_day(month, day):
    days = 0
    mon = {3: 31, 4: 30, 5: 31, 6: 30, 7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31}
    d1 = day - 1
    d2 = 0
    if month != 3:
        for i in range(3, month):
            d2 += mon[i]
    
    return d1 + d2 - 3
