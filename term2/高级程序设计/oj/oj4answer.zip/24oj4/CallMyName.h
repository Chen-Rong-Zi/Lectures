#include <string>
#include <map>
using namespace std;
#include <iostream>
class CallMyName
{
    void** all_functions;
public:
    CallMyName(void* af[5]){
        all_functions=af;
    }
    int call(const string &my_call)
    {
        int a, b,c,temp;
        string my_name=my_call.substr(0,my_call.find_first_of('('));
        temp=my_call.find_first_of('(')+1;
        
        void* fp=nullptr;
        int num=0;
        for(int i=0;i<my_call.size();i++){
            if(my_call[i]==',') num++;
        }
        if(my_name=="funcMyAbs"){
            fp=all_functions[0];
        }
        else if(my_name=="funcMySub"){
            fp=all_functions[1];
        }
        else if(my_name=="funcMyHash"){
            fp=all_functions[2];
        }
        else if(my_name=="funcMyAdd"){
            fp=all_functions[3];
        }
        else if(my_name=="funcMySum"){
            fp=all_functions[4];
        }
        
        if(num==0){
            a=stoi(my_call.substr(temp,my_call.find_first_of(')')-temp));
            return ((int(*)(int))fp)(a);
        }
        else if(num==1){
            a=stoi(my_call.substr(temp,my_call.find_first_of(',')-temp));
            temp=my_call.find_first_of(',')+1;
            b=stoi(my_call.substr(temp,my_call.find_first_of(')')-temp));
            return ((int(*)(int,int))fp)(a,b);
        }else{
            a=stoi(my_call.substr(temp,my_call.find_first_of(',')-temp));
            temp=my_call.find_first_of(',')+1;
            b=stoi(my_call.substr(temp,my_call.find(',',temp)-temp));
            temp=my_call.find_first_of(',',temp)+1;
            c=stoi(my_call.substr(temp,my_call.find_first_of(')')-temp));
            return ((int(*)(int,int,int))fp)(a,b,c);
        }
        
    }
};
