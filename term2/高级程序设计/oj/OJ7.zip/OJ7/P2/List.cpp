#include "List.h"

List::List() {
    head.next = &head;
    head.back = &head;
    size_ = 0;
}

List::List(const List &l_) : List() {
    auto cur = l_.head.next;
    while (cur != &l_.head) {
        push_back(cur->e);
        cur = cur->next;
    }
}

List::~List() {
    while (pop_front()) {
    }
}

void List::operator=(const List &l_) {
    if (&l_ == this) {
        return;
    }
    ListNode *cur = head.next;
    while (cur != &head) {
        pop_back();
        cur = cur->next;
    }
    cur = l_.head.next;
    while (cur != &l_.head) {
        push_back(cur->e);
        cur = cur->next;
    }
}

bool List::push_back(const Element &e) {
    return insert(e, head.back);
}

bool List::push_front(const Element &e) {
    return insert(e, &head);
}

bool List::pop_front() {
    if (size_ == 0) {
        return false;
    }
    erase(head.next);
    return true;
}

bool List::pop_back() {
    if (size_ == 0) {
        return false;
    }
    erase(head.back);
    return true;
}

bool List::remove(const Element &e) {
    bool retv = false;
    auto cur = head.next;
    while (cur != &head) {
        auto t = cur;
        cur = cur->next;
        if (t->e == e) {
            retv = true;
            erase(t);
        }
    }
    return retv;
}

bool List::insert(const Element &e, ListNode *ln) {
    ListNode *node = nullptr;
    try {
        node = new ListNode(e);
    } catch (std::bad_alloc) {
        return false;
    }
    node->e = e;
    node->back = ln;
    node->next = ln->next;
    ln->next->back = node;
    ln->next = node;
    ++size_;
    return true;
}

void List::erase(ListNode *ln) {
    --size_;
    ln->back->next = ln->next;
    ln->next->back = ln->back;
    delete ln;
}

ListNode *List::operator[](size_t i) {
    auto cur = head.next;
    int cnt = 0;
    while (cur != &head) {
        if (cnt == i) {
            return cur;
        }
        cur = cur->next;
        ++cnt;
    }
    return nullptr;
}

void List::print() {
    auto cur = head.next;
    while (cur != &head) {
        std::cout << cur->e.num << ' ';
        cur = cur->next;
    }
    std::cout << std::endl;
}
