# include <functional>

# include "ants.h"

void Place::add_insect(std::shared_ptr<Insect> insect) {
    /** Asks the insect to add itself to the current place. This method exists so
     *  it can be enhanced in subclasses.
     */
    insect->add_to(this->shared_from_this());
}

 void Place::remove_insect(std::shared_ptr<Insect> insect) {
    /**
     * Asks the insect to remove itself from the current place. This method exists so it can be enhanced in subclasses.
     */
    insect->remove_from(this->shared_from_this());
}

std::string Place::to_string() {
    return this->name;
}

void Insect::reduce_health(double amount) {
    this->health -= amount;
    if ( this->health <= 0 ) {
        this->death_callback();
        this->place->remove_insect(this->shared_from_this());
    }
}

void Insect::action(std::shared_ptr<GameState> gamestate) {
    /** The action performed each turn.
     *  gamestate -- The GameState, used to access game state information.
     */
    throw std::runtime_error("action Not Implemented Error!");
}

void Insect::death_callback() {
    /** overriden by the gui
     */
    throw std::runtime_error("death_callback Not Implemented Error!");
}

void Insect::add_to(std::shared_ptr<Place> place) {
    /**
     * Add this Insect to the given Place
     * By default just sets the place attribute, but this should be overriden in the subclasses
     *     to manipulate the relevant attributes of Place
     */
    this->place = place;
}

void Insect::remove_from(std::shared_ptr<Place> place) {
    this->place = nullptr;
}

std::string Insect::to_string() {
    return "Insect" + std::to_string(this->health) + this->place->to_string();
}


template <typename T> std::shared_ptr<Ant>
Ant::constructor(std::shared_ptr<GameState> gamestate) {
    if ( T::food_cost > gamestate->food ) {
        print("Not enough food remains to place, the food_cost = ", T::food_cost);
        return nullptr;
    }
    return T();
}

bool Ant::can_contain(std::shared_ptr<Ant> other) {
    return false;
}

std::shared_ptr<Ant> Ant::get_self() {
    return std::dynamic_pointer_cast<Ant>(this->shared_from_this());
}
void Ant::store_ant(std::shared_ptr<Ant> other) {
    throw std::runtime_error("store_ant Not Implemented");
}

void Ant::remove_ant(std::shared_ptr<Ant> other) {
    throw std::runtime_error("store_ant Not Implemented");
}

void Ant::add_to(std::shared_ptr<Place> place) {
    auto self = this->get_self();
    if (place->ant == nullptr) {
        place->ant = self;
    } else if ( place->ant->is_container && place->ant->can_contain(self) ) {
        place->ant->store_ant(self);
    } else if (  this->is_container && this->can_contain(place->ant) ) {
        this->store_ant(place->ant);
        place->ant = self;
    } else {
        throw std::runtime_error("place->ant is None, 'Two ants in {0}'->format(place)");
    }
    this->Insect::add_to(place);
}

void Ant::remove_from(std::shared_ptr<Place> place) {
    auto self = this->get_self();
    if ( place->ant == self )
        place->ant = nullptr;
    else if ( place->ant == nullptr ) {
        throw std::runtime_error(this->to_string() + "Not In " + place->to_string());
    } else {
        place->ant->remove_ant(self);
    }
    this->Insect::remove_from(place);
}

void Ant::buff() {
    /** Double this ants's damage, if it has not already been buffed.
     */

    /* TODO <++>*/
    // if hasattr(self, "buffed"):
        // return
    /* TODO <++>*/
    this->damage = this->damage * 2;
    // this->buffed = true;
}

std::shared_ptr<Bee> ThrowerAnt::nearest_bee() {
    auto walk = this->place;
    int pos = 0;
    while ( ! walk->is_hive ) {
        if ( walk->bees.len() != 0 && pos <= ThrowerAnt::max_range )
            return random_bee(walk->bees);
        walk = walk->entrance;
        pos += 1;
    }
    return nullptr;
}

void ThrowerAnt::throw_at(std::shared_ptr<Bee> target) {
    if ( target != nullptr )
        target->reduce_health(this->damage);
}

void FireAnt::reduce_health(double amount) {
    /* Reduce health by AMOUNT, and remove the FireAnt from its place if it has no health remaining.*/
    // auto bees = shallow_copy(this->place->bees);
    for ( auto bee : this->place->bees ) {
        if ( this->health - amount > 0 )
            bee->reduce_health(amount);
        else
            bee->reduce_health(amount + this->damage);
    }
    Ant::reduce_health(amount);
}

void ContainerAnt::reduce_health(double amount) {
    /* Reduce health by AMOUNT, and remove the FireAnt from its place if it has no health remaining.*/
    // auto bees = shallow_copy(this->place->bees);
    for ( auto bee : this->place->bees ) {
        if ( this->health - amount > 0 )
            bee->reduce_health(amount);
        else
            bee->reduce_health(amount + this->damage);
    }
    Ant::reduce_health(amount);
}

bool ContainerAnt::can_contain(std::shared_ptr<Ant> other) {
    // if (this->ant_contained == nullptr && !(std::dynamic_cast<>))
    if ( this->ant_contained == nullptr )
        return true;
    return false;
}

void ContainerAnt::store_ant(std::shared_ptr<Ant> ant) {
    this->ant_contained = ant;
}

void ContainerAnt::remove_ant(std::shared_ptr<Ant> ant) {
    this->ant_contained = nullptr;
}

void ContainerAnt::remove_from(std::shared_ptr<Place> place) {
    if ( place->ant ==  this->shared_from_this() ) {
        place->ant = this->ant_contained;
        Insect::remove_from(place);
    } else {
        Ant::remove_from(place);
    }
}

void TankAnt::action(std::shared_ptr<GameState> gamestate) {
    for ( auto bee : this->place->bees )
        bee->reduce_health(this->damage);
    if ( this->ant_contained != nullptr )
        this->ant_contained->action(gamestate);
}


void HarvesterAnt::action(std::shared_ptr<GameState> gamestate) {
    /**
     *Produce 1 additional food for the colony.
     *gamestate -- The GameState, used to access game state information.
     */
    gamestate->food += 1;
}

void ThrowerAnt::action(std::shared_ptr<GameState> gamestate) {
    this->throw_at(this->nearest_bee());
}

void HungryAnt::action(std::shared_ptr<GameState> gamestate) {
    if ( this->chew_countdown <= 0 && this->place->bees.len() != 0 ) {
        std::shared_ptr<Bee> bee = random_bee(this->place->bees);
        bee->reduce_health(bee->health);
        this->chew_countdown = this->chew_duration;
    } else {
        this->chew_countdown -= 1;
    }
}

void ContainerAnt::action(std::shared_ptr<GameState> gamestate) {
    if ( this->ant_contained != nullptr )
        this->ant_contained->action(gamestate);
}

List<std::shared_ptr<Ant>> QueenAnt::behind_ants(std::shared_ptr<Place> place) {
    if ( place == nullptr )
        return List<std::shared_ptr<Ant>>();
    return cons(place->ant, behind_ants(place->exit));
}

void QueenAnt::reduce_health(double amount) {
    /**
     *Reduce health by AMOUNT, and if the QueenAnt has no health remaining, signal the end of the game.
     */
    if ( amount < this->health )
        Ant::reduce_health(amount);
    else
        ants_lose();
}



QueenAnt::QueenAnt(std::shared_ptr<GameState> gamestate) {
    gamestate->has_queen = true;
};

void QueenAnt::action(std::shared_ptr<GameState> gamestate) {
    /**
     *A queen ant throws a leaf, but also doubles the damage of ants
     * in her tunnel.
     */
    // 因为Queen直接继承自ant，所以没有实现action的父类
    ScubaThrower::action(gamestate);
    auto ants = this->behind_ants(this->place->exit);
}


void Bee::sting(std::shared_ptr<Ant> ant) {
    ant->reduce_health(this->damage);
}

void Bee::move_to(std::shared_ptr<Place> place) {
    this->place->remove_insect(this->get_self());
}


void Bee::add_to(std::shared_ptr<Place> place) {
    place->bees.append(this->get_self());
    Insect::add_to(place);
}

void Bee::remove_from(std::shared_ptr<Place> place) {
    place->bees.remove(this->get_self());
    Insect::remove_from(place);
}


void Bee::action(std::shared_ptr<GameState> gamestate) {
    auto destination = this->place->exit;

    if ( this->blocked() ) {
        this->sting(this->place->ant);
    } else if ( this->health > 0 && destination != nullptr ) {
        this->move_to(destination);
    }
}


void Hive::strategy(std::shared_ptr<GameState> gamestate) {
    auto places = map_to_list(gamestate->places);
    auto place_ptrs = map(places, [=] (auto str_place) {return str_place.second;});
    auto exits = filter(place_ptrs, [&] (auto p) {return p->entrance == this->get_self();});
    for ( auto bee : this->assault_plan->get(gamestate->time) )
    {
        bee->move_to(exits.random_choice());
        gamestate->active_bees.append(bee);
    }
}


Hive::Hive(std::shared_ptr<AssaultPlan> assault_plan):
    Place("Hive", nullptr),
    assault_plan(assault_plan)
{
    this->bees = List<std::shared_ptr<Bee>>();
    for ( auto it : this->assault_plan->all_bees() )
    {
        this->add_insect(it);
    }
}


void GameState::configure(std::shared_ptr<Hive> beehive, std::shared_ptr<PlaceManager> place_manager) {
    this->base   = std::make_shared<AntHomeBase>("Ant Home Base");
    this->places = std::map<std::string, std::shared_ptr<Place>>();
    this->bee_entrances = List<std::shared_ptr<Place>>();
    place_manager->register_place(this->beehive, false);
    place_manager->set_layout(this->dimensions->first, this->dimensions->second, 0);
}


bool GameState::simulate() {
    /* Simulate an attack on the ant colony (i.e., play the game).   */
    int num_bees = this->bees().len();
    try {
        while (true) {
            this->beehive->strategy(this->shared_from_this());         // Bees invade
            this->strategy(this->shared_from_this());                 // Ants deploy
            for (auto ant : this->ants() ) {              // Ants take actions
                if ( ant->health > 0 )
                    ant->action(this->shared_from_this());
            }
            // <++> python version was using active_bees copy rather than themselves
            for (auto bee : this->active_bees) {     // Bees take actions
                if ( bee->health > 0 )
                    bee->action(this->shared_from_this());
                else if ( bee->health <= 0 ) {
                    num_bees -= 1;
                    this->active_bees.remove(bee);
                }
            }
            if ( num_bees == 0 )
                throw AntsWinException();
            this->time += 1;
        }
    } catch (AntsWinException) {
        print("All bees are vanquished. You win!");
        return true;
    } catch (AntsLoseException) {
        print("The ant queen has perished. Please try again.");
        return false;
    }
}

std::shared_ptr<Ant> GameState::deploy_ant(std::string place_name, std::string ant_type_name) {
    /** Place an ant if enough food is available.
    * This method is called by the current strategy to deploy ants.
    * **/
    std::shared_ptr<Ant> ant = InsectFactory::newAnt(ant_type_name, this->shared_from_this());
    if ( ant == nullptr )
        return nullptr;
    this->places[place_name]->add_insect(ant);
    this->food -= ant->food_cost;
    return ant;
}

void GameState::remove_ant(std::string place_name) {
    /*  Remove an Ant from the game.  */
    auto place = this->places[place_name];
    if ( place->ant != nullptr )
        place->remove_insect(place->ant);
}


List<std::shared_ptr<Insect>> GameState::ants() {
    auto place_list = map_to_list(this->places);
    auto places_with_ant = filter(place_list, [=] (std::pair<std::string, std::shared_ptr<Place>> name_place) {
            return name_place.second->ant != nullptr;
        });
    return map(places_with_ant, [=] (auto name_place) { return std::dynamic_pointer_cast<Insect>(name_place.second->ant); });
}

List<std::shared_ptr<Insect>> GameState::bees() {
    auto place_list = map_to_list(this->places);
    auto bee_lists = map(place_list, [=] (auto name_place) {
            return map(name_place.second->bees, [=] (auto bee) {
                    return std::dynamic_pointer_cast<Insect>(bee);
                });
            });
    return reduce([=] (List<std::shared_ptr<Insect>> pre, List<std::shared_ptr<Insect>> curr) {return pre + curr;}, bee_lists, List<std::shared_ptr<Insect>>());
    // return List<std::shared_ptr<Insect>>();
}


List<std::shared_ptr<Insect>> GameState::insects() {
    return this->ants();
}


std::string GameState::to_string() {
    std::string status = std::string(" (Food: ") + std::to_string(this->food) + std::string(", Time: ") + std::to_string(this->time) + std::string(")");
    auto ins_str = map(this->insects(), [=] (auto ins) {
            return ins->to_string();
        });
    auto res = reduce([=] (auto pre, auto curr) {
            return pre + ", " + curr;
            }, ins_str, std::string(""));
    return res + status;
}

std::map<int, List<std::shared_ptr<Bee>>> AssaultPlan::add_wave(std::string bee_name, double bee_health, int time, int count) {
    /*  Add a wave at time with count Bees that have the specified health.  */
    auto new_bees = map(range(0, count, 1), [=] (int i) {
            return InsectFactory::newBee(bee_name);
        });
    if ( this->plan.find(time) == this->plan.end() )
        this->plan[time] = new_bees;
    else {
        this->plan[time].extend(new_bees);
    }
    return this->plan;
}


List<std::shared_ptr<Bee>> AssaultPlan::all_bees() {
    /*  Place all Bees in the beehive and return the list of Bees.  */
    auto place_with_bee = map(map_to_list(this->plan), [=] (auto int_beeptr) {
            return filter(int_beeptr.second, [=] (auto bee) {
                    return bee != nullptr;
                });
            });
    return reduce([=] (auto pre, auto curr) {
            return pre + curr;
        }, place_with_bee, List<std::shared_ptr<Bee>>());
}


List<std::shared_ptr<Bee>> AssaultPlan::get(int time) {
    if ( this->plan.find(time) == this->plan.end() )
        return List<std::shared_ptr<Bee>>();
    return this->plan[time];
}

std::shared_ptr<Ant> InsectFactory::newAnt(std::string type_name, std::shared_ptr<GameState> gamestate) {
    if ( InsectFactory::cost_map.find(type_name) == InsectFactory::cost_map.end() )
        throw std::runtime_error(type_name + " Not In cost_map ！");
    else if ( InsectFactory::cost_map[type_name] > gamestate->food ) {
        return nullptr;
    } else if ( type_name == "Harvester" ) {
        return std::make_shared<HarvesterAnt>();
    } else if ( type_name == "Thrower" ) {
        return std::make_shared<ThrowerAnt>();
    } else if ( type_name == "Short" ) {
        return std::make_shared<ShortThrower>();
    } else if ( type_name == "Fire" ) {
        return std::make_shared<FireAnt>();
    } else if ( type_name == "Wall" ) {
        return std::make_shared<WallAnt>();
    } else if ( type_name == "Bodyguard" ) {
        return std::make_shared<BodyguardAnt>();
    } else if ( type_name == "Tank" ) {
        return std::make_shared<TankAnt>();
    } else if ( type_name == "ScubaThrower" ) {
        return std::make_shared<ScubaThrower>();
    } else if ( type_name == "Queen" ) {
        return std::make_shared<QueenAnt>(gamestate);
    } else if ( type_name == "Remover" ) {
        return std::make_shared<AntRemover>();
    } else {
        throw std::runtime_error(type_name + "No such ANT Error!");
    }
}


std::shared_ptr<Bee> InsectFactory::newBee(std::string type_name) {
    if ( InsectFactory::cost_map.find(type_name) == InsectFactory::cost_map.end() ) {
        throw std::runtime_error(type_name + " Not In cost_map ！");
    } else if ( type_name == "Wasp" ) {
        return std::make_shared<Wasp>();
    } else if ( type_name == "NinjaBee" ) {
        return std::make_shared<NinjaBee>();
    } else {
        throw std::runtime_error(type_name + "No such Bee Error!");
    }
}

std::shared_ptr<Bee> random_bee(List<std::shared_ptr<Bee>> bees) {
    if ( bees.len() != 0 )
        return bees.random_choice();
    throw std::runtime_error("bees is empty!");
}


void WetLayoutManager::set_layout(std::shared_ptr<Place> base, int tunnels = 3, int length = 9, int moat_frequency = 3) {
    /*  Register a mix of wet and and dry places.  */
    for ( int tunnel = 0; tunnel < tunnels; tunnel += 1 )
    {
        auto exit = base;
        for ( int step = 0; step < length; step += 1 )
        {
            if ( moat_frequency != 0 && (step + 1) % moat_frequency == 0 )
                exit = std::make_shared<Water>(std::string("water_") + std::to_string(tunnel) + "_" + std::to_string(step), exit);
            else
                exit = std::make_shared<Place>(std::string("tunnel_") + std::to_string(tunnel) + "_" + std::to_string(step), exit);
            this->register_place(exit, step == length - 1);
        }
    }
}

void DryLayoutManager::set_layout(int tunnels = 3, int length = 9, int moat_frequency = 0) {
    /*  Register dry tunnels.  */
    wet_layout(gamestate, queen, register_place, tunnels, length, moat_frequency);
}

std::shared_ptr<AssaultPlan> make_test_assault_plan() {
    auto plan = std::make_shared<AssaultPlan>();
    plan->add_wave("Bee", 3, 2, 1);
    plan->add_wave("Bee", 3, 3, 1);
    return plan;
}


std::shared_ptr<AssaultPlan> make_easy_assault_plan() {
    std::shared_ptr<AssaultPlan> plan = std::make_shared<AssaultPlan>();
    for (auto time : range(3, 16, 2)) {
        plan->add_wave("Bee",      3,  time, 1);
    }
    plan->add_wave("Wasp",     3,  4,    1);
    plan->add_wave("NinjaBee", 3,  8,    1);
    plan->add_wave("Hornet",   3,  12,   1);
    plan->add_wave("Boss",     15, 16,   1);
    return plan;
}



std::shared_ptr<AssaultPlan> make_normal_assault_plan() {
    auto  plan = std::make_shared<AssaultPlan>();
    for (auto time : range(3, 16, 2)) {
        plan->add_wave("Bee", 3, time, 2);
    }
    plan->add_wave("Wasp",     3, 4,  1);
    plan->add_wave("NinjaBee", 3, 8,  1);
    plan->add_wave("Hornet",   3, 12, 1);
    plan->add_wave("Wasp",     3, 16, 1);
    // Boss Stage
    for (auto time : range(21, 30, 2)) {
        plan->add_wave("Bee", 3, time, 2);
    }
    plan->add_wave("Wasp",     3,  22, 2);
    plan->add_wave("Hornet",   3,  24, 2);
    plan->add_wave("NinjaBee", 3,  26, 2);
    plan->add_wave("Hornet",   3,  28, 2);
    plan->add_wave("Boss",     20, 30, 1);
    return plan;
}

std::shared_ptr<AssaultPlan> make_hard_assault_plan() {
    auto plan = std::make_shared<AssaultPlan>();
    for (auto time : range(3, 16, 2)) {
        plan->add_wave("Bee", 4, time, 2);
    }
    plan->add_wave("Hornet",   4, 4,  2);
    plan->add_wave("Wasp",     4, 8,  2);
    plan->add_wave("NinjaBee", 4, 12, 2);
    plan->add_wave("Wasp",     4, 16, 2);
    // Boss Stage
    for (auto time : range(21, 30, 2)) {
        plan->add_wave("Bee", 4, time, 3);
    }
    plan->add_wave("Wasp",     4,  22, 2);
    plan->add_wave("Hornet",   4,  24, 2);
    plan->add_wave("NinjaBee", 4,  26, 2);
    plan->add_wave("Hornet",   4,  28, 2);
    plan->add_wave("Boss",     30, 30, 1);
    return plan;
}

std::shared_ptr<AssaultPlan> make_extra_hard_assault_plan() {
    auto plan = std::make_shared<AssaultPlan>();
    plan->add_wave("Hornet", 5, 2, 2);
    for (auto time : range(3, 16, 2)) {
        plan->add_wave("Bee", 5, time, 2);
    }
    plan->add_wave("Hornet",   5, 4,  2);
    plan->add_wave("Wasp",     5, 8,  2);
    plan->add_wave("NinjaBee", 5, 12, 2);
    plan->add_wave("Wasp",     5, 16, 2);
    // Boss Stage
    for (auto time : range(21, 30, 2)) {
        plan->add_wave("Bee", 5, time, 3);
    }
    plan->add_wave("Wasp",     5,  22, 2);
    plan->add_wave("Hornet",   5,  24, 2);
    plan->add_wave("NinjaBee", 5,  26, 2);
    plan->add_wave("Hornet",   5,  28, 2);
    plan->add_wave("Boss",     30, 30, 2);
    return plan;
}

void ants_lose() {
    throw AntsWinException();
}

void ants_win() {
    throw AntsLoseException();
}

bool start_with_strategy(std::function<void (std::shared_ptr<GameState>)> strategy) {
   /*  Reads command-line arguments and starts a game with those options  */
   auto assault_plan = make_normal_assault_plan();
   const int tunnel_length = 10;
   const int num_tunnels = 3;
   const int food = 5;
   auto beehive = std::make_shared<Hive>(assault_plan);
   auto dimensions = std::make_shared<std::pair<int, int>>(num_tunnels, tunnel_length);
   return std::make_shared<GameState>(strategy, beehive, dry_layout(), dimensions, food)->simulate();
}

int main(const int arg_number, const char **arg_value) {
    // std::make_shared<GameState>();
    // start_with_strategy([=] (std::shared_ptr<GameState> gamestate) {
                // return;
            // });
}
