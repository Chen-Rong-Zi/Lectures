"""write your code in method"""


def is_triangle(a, b, c):
    # 
    if a < (b + c) and b < (c + a) and c < (a + b) and a > abs(b - c) and b > abs(c - a) and c > abs(a - b):
        return True
    else
        return False
    # 返回True or False
