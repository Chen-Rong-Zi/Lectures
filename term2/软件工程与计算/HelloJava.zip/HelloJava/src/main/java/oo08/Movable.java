package oo08;

public interface Movable {
    void move();
}
