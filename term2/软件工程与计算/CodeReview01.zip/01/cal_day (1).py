"""write your code in method"""


def get_day(month, day):
    days = day - 4
    mon_list = [0, 31, 61, 92, 122, 153, 183, 214, 244, 275]
    for i in range(10):
        if month == i + 3:
            days += mon_list[i]
    return days
