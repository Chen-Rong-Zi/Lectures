package game10.chess;

public enum GameResult {
    X_Win,
    O_Win,
    DRAW,
    GAMING
}
