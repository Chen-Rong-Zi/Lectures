#ifndef FIBNACCI_H_
#define FIBNACCI_H_
#include <cstdint>

template<size_t n>
struct fibnacci {
    static constexpr size_t value = fibnacci<n - 1>::value + fibnacci<n - 2>::value;
};

template<>
struct fibnacci<0> {
    static constexpr size_t value = 0;
};

template<>
struct fibnacci<1> {
    static constexpr size_t value = 1;
};

#endif