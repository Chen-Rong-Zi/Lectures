#include <iostream>
#include <string>
#include <vector>
using namespace std;
class Library;
class Book {
private:
    string title;
    string author;
    int number;
    int number_max;
    bool available;

public:
    Book(const string &t, const string &a,int num=1) : title(t), author(a), available(true), number(num), number_max(num) {}
    // 声明友元函数
    friend int borrowBook(Library &lib, const string &title);
    friend int returnBook(Library &lib, const string &title);
    friend class Library;
    
};
class Library {
private:
    vector<Book> books;

public:
    void addBook(const Book &book);
    void printBooks();

    // 声明友元函数
    friend int borrowBook(Library &lib, const string &title);
    friend int returnBook(Library &lib, const string &title);
};

