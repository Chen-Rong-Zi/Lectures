#include "Vector.h"
#include <iostream>

Vector Vector::map(map_func f) const
{
    vector<int> ans;
    for (int i : vec_)
    {
        ans.push_back(f(i));
    }
    return Vector(ans);
}

Vector Vector::filter(filter_func f) const
{
    vector<int> ans;
    for (int i : vec_)
    {
        if (f(i))
            ans.push_back(i);
    }
    return Vector(ans);
}

Vector &Vector::for_each(map_func f)
{
    for (int &i : vec_)
        i = f(i);
    return *this;
}

void Vector::output() const
{
    for (int i : vec_)
        cout << i << ' ';
    cout << endl;
}