#include<cstring>
#include<iostream>
#include<stack>
using namespace std;

// 补充solution函数，参数为题目输入的str，在该函数内输出结果
void solution(const char* str)
{

    // TODO
    stack<char> a;
    for(int i=0;i<strlen(str);i++)
    {
    	char s=str[i];
    	if(s=='N'&&a.empty())a.push(s);
    	else if(s=='J' && a.top()=='N')a.push(s);//NJ
    	else if(s=='U' && a.top()=='J'){//NJU
			cout<<"Yes"<<endl;
			return ;
		}
	}
	cout<<"No"<<endl;
}

// 我们为你提供了main函数，处理了输入，你只需要关注solution函数
// 如果你需要对string类型直接进行操作，可自行修改，测评只关注输出的内容
int main()
{
    string s1;
    cin >> s1 ;
    
    const char* str = s1.c_str();
    
    solution(str);

    return 0;
}