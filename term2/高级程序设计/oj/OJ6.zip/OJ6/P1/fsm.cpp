#include "fsm.h"
// 可以添加任何你想要的 stl
#include <map>
#include <vector>
#include <iostream>
// 请自由发挥

bool my_fsm::add_accept_state(const std::string &state) {
    return accept_states.insert(state).second;
}

bool my_fsm::add_transit(const std::string &src, const std::string &dest,
                         char symbol) {
    return state_transitions[src].insert({symbol, dest}).second;
}

bool my_fsm::execute(const std::string &input) {
    auto current_state = start_state;
    for (const char iter : input) {
        const dest_map &cur_trans = state_transitions[current_state];
        const auto &dest = cur_trans.find(iter);
        if (dest == cur_trans.end()) {
            return false;
        }
        current_state = dest->second;
    }
    return accept_states.find(current_state) != accept_states.end();
}