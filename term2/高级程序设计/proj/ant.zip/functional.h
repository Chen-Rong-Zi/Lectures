# pragma once
# include <iostream>
# include <string>
# include <stdexcept>
# include <memory>
# include <random>
# include <functional>
# include <map>
# include <utility>

namespace cp {
    template <typename T, typename U>
    struct is_same_helper {
        static const bool res = false;
    };

    template <typename T>
    struct is_same_helper<T, T> {
        static const bool res = true;
    };

    template <typename T, typename U>
    constexpr bool is_same = is_same_helper<T, U>::res;

    template <typename T>
    concept Iterable = requires(T iter) {
        iter.begin();
        iter.end();
        ++(iter.begin());
    };

    template <typename T>
    concept NotIterable = !Iterable<T>;

    template <typename Func, typename... Args>
    concept Callable = requires(Func func, Args... args) {
        func(args...);
    };

    template <typename T>
    concept LinkedList = Iterable<T> && requires (T lst) {
        car(lst);
        cdr(lst);
        lst.is_nil();
    };

    template <typename... Args>
    concept least_one_arg = sizeof...(Args) >= 1;

}

namespace fp {
    using namespace cp;

    template <typename T>
    class Node;

    template <typename T>
    class List;
    template <typename T>
    List<T> cons(const T &, const List<T> &);
    template <typename T>
    List<T> cons(const T &);
    int randint(int, int);

    template <typename T>
    class Iterator {
    public:
        std::shared_ptr<Node<T>> pnode = std::make_shared<Node<T>>();
    public:
        Iterator(std::shared_ptr<Node<T>> pnode) {
            this->pnode = pnode;
        }
        T operator*() {
            return this->pnode->content;
        }
        bool operator != (auto &other) {
            return this->pnode != NULL;
        }
        Iterator &operator ++ () {
            this->pnode = this->pnode->rest;
            return *this;
        }
        Iterator operator ++ (int) {
            Iterator old = *this;
            this->pnode = this->pnode->rest;
            return old;
        }
        bool operator==(const Iterator &other) const {
            return this->pnode == other.pnode;
        }
    };

    template <typename T>
    class Node {
    public:
        std::shared_ptr<Node<T>> rest;
        T content;
    public:
        Node(const T &content, const std::shared_ptr<Node<T>> &rest) {
            this->content = content;
            this->rest    = rest;
        }
        Node(const Node &other) {
            this->rest    = other.rest;
            this->content = other.content;
        }
        Node() {
            this->rest    = std::shared_ptr<Node<T>>();
        }
    };

    template <typename T>
    struct is_container_helper {
        static const bool res = false;
    };

    template <typename T>
    struct is_container_helper<List<T>> {
        static const bool res = true;
    };

    template <typename T>
    const bool is_container = is_container_helper<T>::res;

    template <typename T>
    class List {
    public:
        std::shared_ptr<Node<T>> head;
    public:
        List() {
            this->head = std::shared_ptr<Node<T>>();
        }

        List(std::shared_ptr<Node<T>> head) {
            this->head = head;
        }

        List(auto first, auto... params) {
            if constexpr ( sizeof...(params) == 0 ) {
                *this = cons(first);
            }
            else {
                *this = cons(first, List(params...));
            }
        }

        List(const List &other) {
            this->head = other.head;
        }

        bool is_nil() const {
            if constexpr ( is_container<T> ) {
                return car(*this).is_nil();
            }
            else {
                return this->head == nullptr;
            }
        }

        int len_helper(const List &lst, int n) const {
            if ( lst.is_nil() )
                return n;
            return len_helper(cdr(lst), n + 1);
        }

        int len() const {
            return this->len_helper(*this, 0);
        }

        T car_n(int n) const {
            if ( n < 0 || n >= this->len() ) {
                std::string error_msg = std::string("car_n: List Bound Exceeded Error!  ") + std::to_string(n) + " of len(*this) = " + std::to_string(this->len());
                throw std::runtime_error(error_msg);
            }
            if ( n == 0 )
                return car(*this);
            return cdr(*this).car_n(n - 1);
        }
        List<T> n_forward(int n) const {
            if ( this->is_nil() )
                throw std::runtime_error("n_forward: List Bound Exceeded Error!");
            if ( n == 0 )
                return List<T>();
            return cons(car(*this), cdr(*this).n_forward(n-1));
        }

        void append(T ele) {
            if ( this->is_nil() ) {
                *this = cons(ele);
                return;
            }
            List<T> cdr_list = cdr(*this);
            cdr_list.append(ele);
            *this = cons(car(*this), cdr_list);
        }

        void extend(const List<T> other) {
            map(other, [=] (T ele) {
                    this->append(ele);
                    return 0;
                });
        }

        void remove(T ele) {
            if ( this->is_nil() )
                return;
            else if ( car(*this) == ele) {
                *this = cdr(*this);
                return;
            }
            List<T> cdr_list = cdr(*this);
            cdr_list.remove(ele);
            *this = cons(car(*this), cdr_list);
        }

        template <typename F>
        requires requires(F func, T temp) {
            requires Callable<F, T>;
            requires is_same<bool, decltype(func(temp))>;
        }
        int count_if(F func) {
            if ( this->is_nil() )
                return 0;
            return func(car(*this)) + cdr(*this).count(func);
        }

        List<T> operator+(List<T> other) {
            List<T> c;
            c.extend(*this);
            c.extend(other);
            return c;
        }

        List<T> n_backward(int n) const {
            if ( this->is_nil() )
                return List<T>();
            if ( this->len() == n )
                return shallow_copy(*this);
            return shallow_copy(cdr(*this).n_backward(n));
        }

        List<List<T>> split() {
            int length = this->len();
            List<T> left  = this->n_forward(length / 2);
            List<T> right = this->n_backward(length - length / 2);
            return cons(left, cons(right));
        }

        Iterator<T> begin() {
            return Iterator(this->head);
        }

        Iterator<T> end() {
            return Iterator<T>(NULL);
        }

        T random_choice() const {
            const int random_int = randint(0, this->len() - 1);
            return this->car_n(random_int);
        }
    };

    template <int base, int end, int iter, typename... Args>
    auto _range_helper(Args... args) {
        if constexpr ( base >= end - 1 ) {
            return List<int>(args...);
        } else if constexpr( sizeof...(args) == 0 ) {
            return List<int>();
        } else {
            return _range_helper<base + iter, end, iter>(args..., base + iter);
        }
    }

    template <int base, int end = -1, int iter = -96>
    List<int> range_const() {
        if constexpr ( end == -1 && iter == -96 )
            return _range_helper<0, base, 1>(0);
        else if constexpr ( iter == -96 ) {
            return _range_helper<base, end, 1>(base);
        }
        else {
            return _range_helper<base, end, iter>(base);
        }
    }

    List<int> range(int begin, int end, int step) {
        auto new_range = List<int>();
        for ( int i = begin; i < end; i += step )
        {
            new_range.append(i);
        }
        return new_range;
    }

    template <typename T>
    List<T> sorted(List<T> lst) {
        if ( lst.len() < 2) {
            return shallow_copy(lst);
        }
        List<T> rest = sorted(cdr(lst));
        if ( car(lst) < car(rest) ) {
            return cons(car(lst), rest);
        }
        else {
            return cons(car(rest), sorted(cons((car(lst)), cdr(rest))));
        }
    }

    template <typename T>
    List<T> reversed(List<T> lst) {
        auto res = List<T>();
        for ( const auto &it : lst )
            res = cons(it, res);
        return res;
    }

    template <typename T>
    static List<T> shallow_copy(List<T> lst) {
        if ( lst.is_nil() )
            return List<T>();
        return cons(car(lst), shallow_copy(cdr(lst)));
    }

    template <typename T>
    List<T> merge(List<T> left, List<T> right, auto compare_func) {
        if ( left.is_nil() )
            return right;
        if ( right.is_nil() )
            return left;
        if ( compare_func(car(left), car(right)) )
            return cons(car(left), merge(cdr(left), right, compare_func));
        else
            return cons(car(right), merge(left, cdr(right), compare_func));
    }

    template <typename T>
    List<T> merge_sort(const List<T> &lst, auto &compare_func) {
        if ( lst.len() < 2 ) {
            return shallow_copy(lst);
        }
        int length = lst.len();
        List<T> left  = merge_sort(lst.n_forward(length / 2), compare_func);
        List<T> right = merge_sort(lst.n_backward(length - length / 2), compare_func);
        return merge(left, right, compare_func);
    }

    int randint(int start, int end) {
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_int_distribution<> dis(start, end);
        int random_number = dis(gen);
        return random_number;
    }

    template <typename T>
    List<T> cons(const T &content, const List<T> &rest) {
        return List<T>(std::shared_ptr<Node<T>>(new Node<T>(content, rest.head)));
    }

    template <typename T>
    List<T> cons(const T &content) {;
        return List<T>(std::shared_ptr<Node<T>>(new Node<T>(content, nullptr)));
    }

    template <typename T>
    T car(const List<T> &lst) {
        return lst.head->content;
    }

    template <typename T>
    List<T> cdr(const List<T> &lst) {
        return List<T>(lst.head->rest);
    }

    template <typename T>
    List<T> n_cdr(const List<T> &lst, int n) {
        if ( n == 0 )
            return lst;
        return n_cdr(cdr(lst), n-1);
    }

    auto curry(auto func, auto... params) {
        if constexpr ( requires { func(params...); } ) {
            return func(params...);
        }
        else {
            return [func, params...] (auto... new_params) {
                return curry(func, params..., new_params...);
            };
        }
    }

    auto reverse_reduce(auto func, auto lst, auto initial) {
        if ( lst.is_nil() )
            return initial;

        return func(reverse_reduce(func, cdr(lst), initial), car(lst));
    }

    template <typename Func, typename U, typename T>
    requires requires(Func func, U lst, T initial) {
        requires Iterable<U>;
        requires Callable<Func, T, decltype(*(lst.begin()))>;
    }
    T reduce(Func func, U lst, T initial) {
        for ( auto it : lst  ) {
            initial = func(initial, it);
        }
        return initial;
    }

    template <typename Func, typename U>
    requires requires(Func func, U lst) {
        requires LinkedList<U>;
        requires Callable<Func, decltype(car(lst)), decltype(car(lst))>;
    }
    auto special(Func func, U lst) {
        return reduce(func, lst, car(lst));
    }

    template <typename U>
    requires LinkedList<U>
    auto zip(U lst1, U lst2) {
        if ( lst1.is_nil() )
            return cons(U());
        auto first = cons(car(lst1), cons(car(lst2)));
        auto rest  = zip(cdr(lst1),  cdr(lst2));
        return cons(first, rest);
    }

    template <template <typename>typename C, typename T>
    auto map(C<T> lst, auto func) {
        auto map_func = [=] (auto pre, auto curr) {
            return cons(func(curr), pre);
        };
        return reversed(reduce(map_func, lst, C<decltype(func(car(lst)))>()));
    }

    auto lazy_map(auto func, auto array) {
        return curry(map<decltype(func), decltype(array)>)(func);
    }

    auto filter(auto lst, auto filter_func) {
        auto func = [=](auto pre, auto curr) {
            if ( filter_func(curr) )
                return cons(curr, pre);
            return pre;
        };
        return reversed(reduce(func, lst, decltype(lst)()));
    }

    auto lazy_filter(auto func, auto array) {
        return curry(filter<decltype(func), decltype(array)>)(func);
    }

    auto lazy_sorted(auto compare_func, auto lst) {
        return curry(sorted<decltype(compare_func), decltype(lst)>)(compare_func);

    }

    template <typename K, typename V>
    auto map_to_list(std::map<K, V> amap) {
        auto new_list = List<std::pair<K, V>>();
        for ( auto &it : amap )
            new_list.append(it);
        return new_list;
    }

    // auto compose(auto working_list, auto initial) {
        // auto func = [=](auto pre, auto curr){
            // return curr(pre);
        // };
        // return reduce(func, working_list, initial);
    // }

    // template <typename Func>
    // requires requires(Func func)Callable<Func>
    // auto compose(Func first_func, auto second_func) {
        // return [=] (auto args) {return second_func(first_func(args));};
    // }

    auto compose(auto first_func, auto... funcs) {
        return compose(first_func, compose(funcs...));
    }
}

namespace util {
    using namespace cp;

    void print_one(NotIterable auto car) {
        std::cout << car << " ";
    }

    void print_one(std::string car) {
        std::cout << '"' << car << '"' << " ";
    }

    void print_one(Iterable auto lst) {
        std::cout << "{ ";
        for (auto i : lst) {
            print_one(i);
        }
        std::cout << "} ";
    }

    void print() {
        std::cout << std::endl;
    }

    void print(auto arg, auto... args) {
        print_one(arg);
        print(args...);
    }

    // template <typename T, typename U>
    // constexpr bool is_same = false;

    // template <typename T>
    // constexpr bool is_same<T, T> = true;

    template <typename T>
    concept Addable = requires(T a, T b) {
        a + b;
    };

    template <typename... Args>
    requires (Addable<Args> && ...)
    auto sum(Args... args) {
        return (... + args);
    }

    auto mul(auto... args) {
        return (1 * ... * args);
    }

    bool all(Iterable auto iter) {
        for ( const auto &it :  iter )
        {
            if ( it == false )
                return false;
        }
        return true;
    }

    bool any(Iterable auto iter) {
        for ( const auto &it :  iter )
        {
            if ( it == true )
                return true;
        }
        return false;
    }

    // bool all(auto... args) {
        // return (true && ... && args);
    // }

    // bool any(auto... args) {
        // return (true || ... || args);
    // }

    auto get_all(auto... args) {
        (std::cin >> ... >> args) ;
    }

    auto max(auto first, auto&... args) {
        if constexpr ( sizeof...(args) == 0 ) {
            return first;
        }
        else {
            auto second = max(args...);
            return (first > second) ? first : second;
        }
    }

    // template <typename T>
    // auto max(vector<T> lst) {
        // T mymax = [=] (auto pre, auto curr) {
            // return (pre > curr) ? pre : curr;
        // };
        // return fp::special(mymax, lst);
    // }

    auto min(auto first, auto... args) {
        if constexpr ( sizeof...(args) == 0 ) {
            return first;
        }
        else {
            auto second = min(args...);
            return (first < second) ? first : second;
        }
    }

    template <typename T>
    auto min(std::vector<T> lst) {
        auto mymin = [=](auto pre, auto curr) {
            return (pre < curr) ? pre : curr;
        };
        return fp::special(mymin, lst);
    }
}
