package game10.tictactoe;

public enum Result {
    X_WIN, O_WIN, DRAW, GAMING
}
