// String.cpp
#include "String.h"
#include <cstring>

void String::print() { cout << str_p << endl; }

String::String() {
    len = 0;
    str_p = new char[len + 1];
    str_p[0] = '\0';
}

String::String(const char *s) {
    len = strlen(s);
    str_p = new char[len + 1];
    strcpy(str_p, s);
}

String::String(const String &s) {
    len = s.len;
    str_p = new char[len + 1];
    strcpy(str_p, s.str_p);
}

String::~String() {
    if (str_p != nullptr) {
        delete[] str_p;
        str_p = nullptr;
    }
}

String &String::operator=(const String &s) {
    if (this == &s) {
        return *this;
    }
    if (str_p != nullptr) {
        delete[] str_p;
        str_p = nullptr;
    }
    len = s.len;
    str_p = new char[len + 1];
    strcpy(str_p, s.str_p);
    return *this;
}

String &String::operator=(const char *s) {
    if (str_p == s) {
        return *this;
    }
    if (str_p != nullptr) {
        delete[] str_p;
        str_p = nullptr;
    }
    len = strlen(s);
    str_p = new char[len + 1];
    strcpy(str_p, s);
    return *this;
}

char &String::operator[](int index) { return str_p[index]; }

String String::operator+(const String &s) {
    int len1 = strlen(str_p);
    int len2 = strlen(s.str_p);
    char *temp = new char[len1 + len2 + 1];
    strcpy(temp, str_p);
    strcat(temp, s.str_p);
    String res(temp);
    return res;
}

bool String::operator==(const String &str) {
    if (len != str.len) {
        return false;
    }
    for (int i = 0; i < len; i++) {
        if (str_p[i] != str.str_p[i]) {
            return false;
        }
    }
    return true;
}

bool String::operator!=(const String &str) { return !(*this == str); }

bool String::operator<(const String &str) {
    for (int i = 0; i < len && i < str.len; i++) {
        if (str_p[i] < str.str_p[i]) {
            return true;
        }
        if (str_p[i] > str.str_p[i]) {
            return false;
        }
    }
    return len < str.len;
}