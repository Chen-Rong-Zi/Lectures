package oo08;

public abstract class Animal {
    int height;

    public void eat(){
        System.out.println("oo.Animal eat!");
    }
    public  abstract void sleep();

    public static void main(String[] args){

    }
}
