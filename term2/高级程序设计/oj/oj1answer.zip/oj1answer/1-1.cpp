#include<iostream>
using namespace std;
 
 
void solve(int n){
    int sz = 26;
    string ans;
    for(int i = 1; i <= sz; i++){
        for(int j = 1; j <= sz; j++){
            for(int k = 1; k <= sz; k++){
                for(int w = 1; w <= sz; w++){
                    if(i + j + k + w  == n){
                        ans = char(w -1 + 'a');
                        ans += char(k -1 + 'a');
                        ans += char(j -1 + 'a');
                        ans += char(i -1 + 'a');
                        cout <<ans << "\n";
                        return;
                    }
                }
            }
        }
    }
 
}
int main(){
    int n;
    cin>>n;
    solve(n);
}