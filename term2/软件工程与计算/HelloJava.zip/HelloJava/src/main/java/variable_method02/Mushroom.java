package variable_method02;

public class Mushroom{
    public int size;
    public boolean isMagic;

    public Mushroom(int size){
    }

    public Mushroom(boolean isMagic){
    }
    public Mushroom(boolean isMagic, int size){
    }
    public Mushroom(int size, boolean isMagic){
    }

}
