#include "Class.h"
#include <iostream>

void Class::add_function(const Function &func) { this->funcs.emplace_back(func); }
void Class::inherit(const Class &c) { this->parent = &c; }
bool call(CallSite callsite) {
    const auto *cur_arg = &callsite.arg;
    bool matched = false;
    while (cur_arg != nullptr) {
        for (const auto &iter : callsite.base.funcs) {
            if (iter.name == callsite.function_name) {
                matched = true;
                if (cur_arg->name == iter.arg.name) {
                    cout << callsite.base.name << "::" << iter.name << "("
                         << cur_arg->name << ")" << endl;
                    return true;
                }
            }
        }
        cur_arg = cur_arg->parent;
    }
    if (callsite.base.parent != nullptr && !matched) {
        return call({*callsite.base.parent, callsite.function_name, callsite.arg});
    }
    cout << "Function not found." << endl;
    return false;
}
bool Class::is_ancestor(const Class &c) const {
    if (*this->parent == c) {
        return true;
    }
    if (this->parent == nullptr) {
        return false;
    }
    return this->parent->is_ancestor(c);
}
