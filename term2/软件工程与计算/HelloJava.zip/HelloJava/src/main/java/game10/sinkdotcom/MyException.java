package game10.sinkdotcom;

public class MyException extends Exception{
}
