"""write your code in method"""


def get_circ(radius):
    # C = 2 * PI * R
    return 2 * radius * 3
