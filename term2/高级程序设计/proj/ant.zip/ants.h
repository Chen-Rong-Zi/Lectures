# pragma once

# include <iostream>
# include <string>
# include <stdexcept>
# include <memory>
# include <map>
# include <utility>
# include <functional>

# include <self/functional.h>

using namespace util;
using namespace fp;
class Insect;
class Bee;
class Place;
class Ant;
class HarvesterAnt;
class ThrowerAnt;
class ShortThrower;
class LongThrower;
class FireAnt;
class WallAnt;
class HungryAnt;
class ContainerAnt;
class BodyguardAnt;
class TankAnt;
class Water;
class ScubaThrower;
class QueenAnt;
class AntRemover;
class Wasp;
class NinjaBee;
class Hive;
class GameState;
class AntHomeBase;
class AssaultPlan;
class GameOverException;
class AntsWinException;
class AntsLoseException;

class GameOverException : public std::exception {
    /* Base game over Exception. */
    // std::cout << "GameOverException" << std::endl;
};


class AntsWinException : public GameOverException {
    /* Exception to signal that the ants win.   */
    // std::cout << "AntsWinException" << std::endl;
    // std::cout << "AntsWinException" << std::endl;
};


class AntsLoseException : public GameOverException {
    /*  Exception to signal that the ants lose.  */
    // std::cout << "AntsLoseException" << std::endl;
};



class Place : public std::enable_shared_from_this<Place> {
    /** A Place holds insects and has an exit to another Place.
     * */
public:
    const bool is_hive = false;
    List<std::shared_ptr<Bee>> bees = List<std::shared_ptr<Bee>>();
    std::shared_ptr<Ant> ant;        // shared_ptr' s empty constructor stores nullptr, which can represent None
    std::shared_ptr<Place> exit;
    std::shared_ptr<Place> entrance;
    std::string name;
    Place() = default;
    Place(std::string name, std::shared_ptr<Place> exit = nullptr):
        name(name),
        exit(exit)
    {
        /** Create a Place with the given NAME and EXIT.
         * name -- A string; the name of this Place.
         * exit -- The Place reached by exiting this Place (may be None).
        */
        if ( this->exit != nullptr )
            this->exit->entrance = this->shared_from_this();
    };

    Place(std::shared_ptr<Place> other) {
        this->exit     = other->exit;
        this->ant      = other->ant;
        this->entrance = other->entrance;
        this->name     = other->name;
    };

    virtual void add_insect(std::shared_ptr<Insect> insect);
    virtual void remove_insect(std::shared_ptr<Insect> insect);
    virtual std::string to_string();
};

class Insect : public std::enable_shared_from_this<Insect> {
/**
 * An Insect, the base class of Ant and Bee, has health and a Place.
 */
public:
    double damage;
    double health;
    bool is_waterproof = false;
    std::shared_ptr<Place> place;
    Insect():
        health(1),
        place(nullptr),
        damage(0)
    {};
    Insect(double health, std::shared_ptr<Place> place = nullptr):
        health(health),
        place(place),
        damage(0)
    {
        /**
         * Create an Insect with a health amount and a starting PLACE.
         */
    }
    Insect(std::shared_ptr<Insect> other) {
        this->health = other->health;
        this->place  = other->place;
    }
    virtual void reduce_health(double amount);
    virtual void action(std::shared_ptr<GameState> gamestate);
    virtual void death_callback();
    virtual void add_to(std::shared_ptr<Place> place);
    virtual void remove_from(std::shared_ptr<Place> place);
    virtual std::string to_string();
};

class Ant : public Insect {
/**An Ant occupies a place and does work for the colony.
 */

public:
    int food_cost = 0;
    const bool is_container = false;
    Ant(double health = 1.0):
        Insect(health)
    {
        /** Create an Insect with a HEALTH quantity.
         */
    }
    Ant(std::shared_ptr<Ant> other) {
        this->health = other->health;
    }
    template <typename T>
    std::shared_ptr<Ant> constructor(std::shared_ptr<GameState> gamestate);
    virtual bool can_contain(std::shared_ptr<Ant> other);
    void store_ant(std::shared_ptr<Ant> other);
    void remove_ant(std::shared_ptr<Ant> other);
    void add_to(std::shared_ptr<Place> place);
    void remove_from(std::shared_ptr<Place> place);
    virtual std::shared_ptr<Ant> get_self();
    void buff();
};


class HarvesterAnt : public Ant {
    /**
     * HarvesterAnt produces 1 additional food per turn for the colony.
     */
public:
    HarvesterAnt():
        Ant()
    {};
    std::string name = "Harvester";
    int food_cost = 2;

    void action(std::shared_ptr<GameState> gamestate);
};

class ThrowerAnt : public Ant {
public:
    std::string name = "Thrower";
    int min_range = 0;
    int max_range = 2147483647;
    int food_cost = 3;

    ThrowerAnt():
        Ant()
    {
        this->damage = 1;
    }
    std::shared_ptr<Bee> nearest_bee();
    void throw_at(std::shared_ptr<Bee> target);
    void action(std::shared_ptr<GameState> gamestate);
};

std::shared_ptr<Bee> random_bee(List<std::shared_ptr<Bee>> bees);

// ##############
// # Extensions #
// ##############

class ShortThrower : public ThrowerAnt
{
/*  A ThrowerAnt that only throws leaves at Bees at most 3 places away.  */
public:
    ShortThrower():
        ThrowerAnt()
    {};
    std::string name = "Short";
    int max_range = 3;
    int food_cost = 2;
};


class LongThrower : public ThrowerAnt {
    /*  A ThrowerAnt that only throws leaves at Bees at least 5 places away.  */
    std::string name = "Long";
    int min_range = 5;
    int food_cost = 2;
};


class FireAnt : public Ant {
    /* FireAnt cooks any Bee in its Place when it expires.  */
public:
    std::string name = "Fire";
    int damage = 3;
    int food_cost = 5;

    FireAnt(double health = 3):
        Ant(health)
    {};
    void reduce_health(double amount);
};

class WallAnt : public Ant {
public:
    std::string name = "Wall";
    int food_cost = 4;
    WallAnt():
        Ant(4)
    {};
};


class HungryAnt : public Ant {
    std::string name           = "Hungry";
    int         food_cost      = 4;
    int         chew_duration  = 3;
    int         chew_countdown = 0;

    HungryAnt():
        Ant(1),
        chew_countdown(0)
    {};
    void action(std::shared_ptr<GameState> gamestate);
};


class ContainerAnt : public Ant {
    /*  ContainerAnt can share a space with other ants by containing them.  */
public:
    bool is_container = true;
    std::shared_ptr<Ant> ant_contained;

    ContainerAnt(std::shared_ptr<Ant> other):
        Ant(other),
        ant_contained(nullptr)
    {};

    ContainerAnt(double health):
        Ant(health),
        ant_contained(nullptr)
    {};

    void reduce_health(double amount);
    bool can_contain(std::shared_ptr<Ant> other);
    void store_ant(std::shared_ptr<Ant> ant);
    void remove_ant(std::shared_ptr<Ant> ant);
    void remove_from(std::shared_ptr<Place> place);
    virtual void action(std::shared_ptr<GameState> gamestate);
};

class BodyguardAnt : public ContainerAnt {
    /*  BodyguardAnt provides protection to other Ants.  */
public:
    std::string name = "Bodyguard";
    int food_cost = 4;

    BodyguardAnt():
        ContainerAnt(2)
    {};
};

class TankAnt : public ContainerAnt {
public:
    std::string name = "Tank";
    int food_cost = 6;
    double damage = 1;

    TankAnt():
        ContainerAnt(2.0)
    {};

    void action(std::shared_ptr<GameState> gamestate);
};

class Water : public Place {
    /*  Water is a place that can only hold waterproof insects.  */
public:
    Water(std::string name, std::shared_ptr<Place> exit = nullptr):
        Place(name, exit)
    {
    };
    void add_insect(std::shared_ptr<Insect> insect) {
        /* Add an Insect to this place. If the insect is not waterproof, reduce its health to 0.   */
        Place::add_insect(insect);
        if ( (!insect->is_waterproof) && (insect != nullptr) )
            insect->reduce_health(insect->health);
    }
};

class ScubaThrower : public ThrowerAnt {
public:
    std::string name = "ScubaThrower";
    bool is_waterproof = true;
    int food_cost = 6;

    ScubaThrower():
        ThrowerAnt()
    {};
};

class QueenAnt : public ScubaThrower {
    /*  The Queen of the colony. The game is over if a bee enters her place.  */
public:
    std::string name = "Queen";
    int food_cost = 7;

    QueenAnt(std::shared_ptr<GameState> gamestate);

    List<std::shared_ptr<Ant>> behind_ants(std::shared_ptr<Place> place);
    void action(std::shared_ptr<GameState> gamestate);

    void reduce_health(double amount);
};


class AntRemover : public Ant {
    /* Allows the player to remove ants from the board in the GUI.   */
public:
    std::string name = "Remover";
    AntRemover():
        Ant(0.0)
    {};
};


class Bee : public Insect {
    /* A Bee moves from place to place, following exits and stinging ants. */
private:
    std::shared_ptr<Bee> get_self() {
        return std::dynamic_pointer_cast<Bee>(this->shared_from_this());
    }
    bool blocked() {
        return this->place->ant != nullptr;
    }
public:
    std::string name = "Bee";
    int damage = 1;
    Bee():
        Insect()
    {};

    void sting(std::shared_ptr<Ant> ant);
    void move_to(std::shared_ptr<Place> place);
    void action(std::shared_ptr<GameState> gamestate);
    void add_to(std::shared_ptr<Place> place);
    void remove_from(std::shared_ptr<Place> place);
};


class Wasp : public Bee {
    /*  Class of Bee that has higher damage.  */
public:
    std::string name = "Wasp";
    int damage = 2;
};


class NinjaBee : public  Bee {
    /*  A Bee that cannot be blocked. Is capable of moving past all defenses to assassinate the Queen.  */
public:
    std::string name = "NinjaBee";

    bool blocked() {
        return false;
    }
};


class Hive : public Place {
    /**The Place from which the Bees launch their assault.
     *assault_plan -- An AssaultPlan; when & where bees enter the colony.
     */
private:
    std::shared_ptr<Hive> get_self() {
        return std::dynamic_pointer_cast<Hive>(this->shared_from_this());
    }
public:
    bool is_hive = true;
    std::shared_ptr<AssaultPlan> assault_plan;

    Hive(std::shared_ptr<AssaultPlan> assault_plan);

    void strategy(std::shared_ptr<GameState> gamestate);
};

class WetLayoutManager : public std::shared_from_this<PlaceManager> {
private:
    std::shared_ptr<GameState> gamestate;
public:
    WetLayoutManager():
        gamestate(nullptr)
    {};
    void set_gamestate(std::shared_ptr<GameState> gamestate) {
        this->gamestate = gamestate;
    }
    virtual void set_layout(int tunnels, int length, int moat_frequency);
    void register_place(std::shared_ptr<Place> place, bool is_bee_entrance) {
        this->gamestate->places[place->name] = place;
        if (is_bee_entrance) {
            place->entrance = gamestate->beehive;
            this->gamestate->bee_entrances.append(place);
        }
    }
};

class DryLayoutManager : public wet_layout {
    void set_layout(std::shared_ptr<GameState> gamestate, std::shared_ptr<Place> queen, std::function<void (std::shared_ptr<GameState>, std::shared_ptr<Place>, bool)> register_place, int tunnels = 3, int length = 9, int moat_frequency = 0) {
        /*  Register dry tunnels.  */
        wet_layout(gamestate, queen, register_place, tunnels, length, moat_frequency);
    }
};


class GameState : public std::enable_shared_from_this<GameState> {
/**
 * An ant collective that manages global game state and simulates time.
 * Attributes:
 * time -- elapsed time
 * food -- the colony's available food total
 * places -- A list of all places in the colony (including a Hive)
 * bee_entrances -- A list of places that bees can enter
 */
private:
    std::shared_ptr<PlaceManager> place_manager;

public:
    bool has_queen = false;
    int time;
    int food;
    std::function<void (std::shared_ptr<GameState>)> strategy;
    std::shared_ptr<Hive> beehive;
    std::shared_ptr<std::pair<int, int>> dimensions;
    List<std::shared_ptr<Bee>> active_bees;

    std::shared_ptr<AntHomeBase> base;
    std::map<std::string, std::shared_ptr<Place>> places;
    List<std::shared_ptr<Place>> bee_entrances;


    GameState(std::function<void (std::shared_ptr<GameState>)> strategy, std::shared_ptr<Hive> beehive, std::shared_ptr<PlaceManager> place_manager, std::shared_ptr<std::pair<int, int>> dimensions, int food = 2):
        time(0),
        food(food),
        strategy(strategy),
        beehive(beehive),
        dimensions(dimensions),
        active_bees(List<std::shared_ptr<Bee>>()),
        place_manager(place_manager)
    {
        this->place_manager->set_gamestate(this->shared_from_this());
        this->configure(this->beehive, this->place_manager);
    }

    void configure(std::shared_ptr<Hive> beehive, std::shared_ptr<PlaceManager> place_manager);
    bool simulate();
    std::shared_ptr<Ant> deploy_ant(std::string place_name, std::string ant_type_name);
    void remove_ant(std::string place_name);
    List<std::shared_ptr<Insect>> ants();
    List<std::shared_ptr<Insect>> bees();
    List<std::shared_ptr<Insect>> insects();
    std::string to_string();
};

class AntHomeBase : public Place {
    /*  AntHomeBase at the end of the tunnel, where the queen resides.  */
public:
    AntHomeBase(std::string name):
        Place(name)
    {};
    void add_insect(std::shared_ptr<Insect> insect) {
        /** Add an Insect to this Place.
        * Can't actually add Ants to a AntHomeBase. However, if a Bee attempts to
        * enter the AntHomeBase, a AntsLoseException is raised, signaling the end
        * of a game.*/
        // assert isinstance(insect, Bee), "Cannot add {0} to AntHomeBase";
        throw AntsLoseException();
    }
};




// void interactive_strategy(std::shared_ptr<GameState> gamestate) {
//     /** A strategy that starts an interactive session and lets the user make
//     * changes to the gamestate.
//
//     * For example, one might deploy a ThrowerAnt to the first tunnel by invoking
//     * gamestate.deploy_ant('tunnel_0_0', 'Thrower')
//     * */
//     print("gamestate: " + gamestate->to_string());
//     std::string msg = "<Control>-D (<Control>-Z <Enter> on Windows) completes a turn.\n";
//     interact(msg);
// }
// #################
// # Assault Plans #
// #################


class AssaultPlan : public std::enable_shared_from_this<AssaultPlan> {
    /*The Bees' plan of attack for the colony.  Attacks come in timed waves.

    * An AssaultPlan is a dictionary from times (int) to waves (list of Bees).

    * AssaultPlan().add_wave(4, 2)
    * {4: [Bee(3, None), Bee(3, None)]}
    */
public:
    std::map<int, List<std::shared_ptr<Bee>>> plan;
    AssaultPlan():
        plan(std::map<int, List<std::shared_ptr<Bee>>>())
    {};
    std::map<int, List<std::shared_ptr<Bee>>> add_wave(std::string bee_name, double bee_health, int time, int count);
    List<std::shared_ptr<Bee>> all_bees();
    List<std::shared_ptr<Bee>> get(int time);
};

class InsectFactory {
private:
    static std::map<std::string, int> cost_map;
public:

    static std::shared_ptr<Ant> newAnt(std::string type_name, std::shared_ptr<GameState> gamestate);
    static std::shared_ptr<Bee> newBee(std::string type_name);
};

std::map<std::string, int> InsectFactory::cost_map = {
    {"Harvester",    2},
    {"Thrower",      3},
    {"Short",        2},
    {"Fire",         5},
    {"Wall",         4},
    {"Bodyguard",    4},
    {"Tank",         6},
    {"ScubaThrower", 6},
    {"Queen",        7},
    {"Remover",      0}
};

std::shared_ptr<AssaultPlan> make_test_assault_plan();

std::shared_ptr<AssaultPlan> make_easy_assault_plan();

std::shared_ptr<AssaultPlan> make_normal_assault_plan();

std::shared_ptr<AssaultPlan> make_hard_assault_plan();

std::shared_ptr<AssaultPlan> make_extra_hard_assault_plan();

void ants_lose();

void ants_win();
