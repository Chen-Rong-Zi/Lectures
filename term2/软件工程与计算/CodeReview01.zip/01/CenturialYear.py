"""write your code in method"""


def get_year(year):
    str1 = str(year)
    #
    if str1[-2:] == '00' and year % 400 == 0: #
        return True
    else #
        return False
    # return True or False
