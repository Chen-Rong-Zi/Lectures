#include "encryptor.h"
#include <algorithm>

CaesarCipherEncryptor::CaesarCipherEncryptor(int k): key_(k) {}

std::string CaesarCipherEncryptor::encrypt(const std::string &text) const {
    std::string result = text;
    for (char& c: result) {
        c = ((c - 'A') + key_ + 26) % 26 + 'A';
    }
    return result;
}

std::string CaesarCipherEncryptor::decrypt(const std::string &text) const {
    std::string result = text;
    for (char& c: result) {
        c = ((c - 'A') - key_ + 26) % 26 + 'A';
    }
    return result;
}

SubstitutionCipherEncryptor::SubstitutionCipherEncryptor(std::string key): key_(std::move(key)) {}

std::string SubstitutionCipherEncryptor::encrypt(const std::string &text) const {
    std::string result = text;
    for (char& c: result) {
        c = key_[c - 'A'];
    }
    return result;
}

std::string SubstitutionCipherEncryptor::decrypt(const std::string &text) const {
    std::string result = text;
    for (char& c: result) {
        c = 'A' + (std::find(key_.begin(), key_.end(), c) - key_.begin());
    }
    return result;
}