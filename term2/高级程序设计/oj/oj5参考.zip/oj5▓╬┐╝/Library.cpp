#include "Library.h"
#include <algorithm>
void Library::addBook(const Book &book) {
    
    for (auto &b : books) {
        if (b.title == book.title) {
            b.number += book.number; // 如果已存在，则增加数量
            b.number_max += book.number_max; // 增加最大数量
            b.available = b.number >0; // 更新可用状态
            return;
        }
    }
    books.push_back(book);
}

void Library::printBooks() {
    if(books.empty()){
        cout<<"\n";
        return;
    }
    for (const auto &book : books) {
        cout<< book.title << "[" << book.author << "]("
                << (book.available ? "Available" : "All Borrowed") << ")" << endl;
    }
}



int borrowBook(Library &lib, const string &title) {
    for (auto it = lib.books.begin(); it != lib.books.end(); ++it) {
        if (it->title == title && it->available) {
            it->number--;
            if(it->number == 0){
                it->available = false;
            }
            return it->number;
        }
    }
    return -1;
}

// 友元函数 returnBook 定义
int returnBook(Library &lib, const string &title) {
    for (auto it = lib.books.begin(); it != lib.books.end(); ++it) {
        if (it->title == title && it->number < it->number_max) {
            it->number++;
            it->available = true;
           return it->number;
        }
    }
    return -1;
}
