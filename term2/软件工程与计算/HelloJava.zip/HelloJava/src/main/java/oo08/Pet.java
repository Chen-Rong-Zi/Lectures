package oo08;

public interface Pet {

    public void play();
}
