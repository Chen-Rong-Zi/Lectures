#pragma once
#include <string>
#include <utility>
#include <vector>
// 可以添加任何你想要的 stl
#include <map>
#include <set>

using state = std::string;
using state_set = std::set<state>;
using dest_map = std::map<char, state>;
using state_map = std::map<state, dest_map>;

class my_fsm {
  public:
    // 由于保证了不存在非法状态因此没有保存所有状态
    // 如果想进行状态检查添加一个 set 记录所有状态即可
    my_fsm(state start, const std::vector<state>& state_list)
        : start_state(std::move(start)){}; 

    // 添加一个状态转移。该转移从 src 出发，接收符号 symbol 后转移到状态 dest
    bool add_transit(const state &src, const state &dest, char symbol);

    // 将一个状态加入接收状态集合
    bool add_accept_state(const state &state);

    // 启动自动机，判断该串是否是该自动机的语言(能到达接受状态)
    // 输入可能分为多段，请保留状态
    bool execute(const std::string &input);

    // 请自由发挥
  private:
    const state start_state;
    state_set accept_states;
    state_map state_transitions;
};