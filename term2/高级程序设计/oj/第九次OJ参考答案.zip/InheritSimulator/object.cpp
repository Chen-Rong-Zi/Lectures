#include "object.h"

Object::Object(const Class* construct_class,
               std::map<const Class*, Object*>* virtual_classes_map):
               construct_class_(construct_class) {
    for (const auto& member: construct_class->member_variables_) {
        member_variables_.emplace(member, 0);
    }

    for (const auto& p: construct_class->base_classes_) {
        if (p.second) {
            // 如果是虚继承,先看之前有没有创建过同类型的虚基类,如果创建过就不再创建了
            auto it = virtual_classes_map->find(p.first);
            if (it != virtual_classes_map->end()) {
                base_class_objects_.emplace(p.first, it->second);
                continue;
            }
        }

        Object* base_class_object = new Object(p.first, virtual_classes_map);
        if (p.second) {
            virtual_classes_map->emplace(p.first, base_class_object);
        }
        base_class_objects_.emplace(p.first, base_class_object);
    }
}

Object::Object(const Class* construct_class, std::map<const Class*, Object*> virtual_classes_map):
        Object(construct_class, &virtual_classes_map) {}

Object::Object(const Class *construct_class):
        Object(construct_class, std::move(std::map<const Class*, Object*>())) {}

void Object::collect_member_variable_pointer(const std::string& name, std::set<int*>* result) {
    auto it = member_variables_.find(name);
    if (it != member_variables_.end()) {
        // 在当前类找到了对应的成员变量,就停止继续往基类寻找
        result->emplace(&it->second);
        return;
    }

    for (auto& p: base_class_objects_) {
        p.second->collect_member_variable_pointer(name, result);
    }
}

void Object::collect_base_class_object(const Class* base_class, std::set<Object*>* result) {
    if (base_class == construct_class_) {
        result->emplace(this);
        return;
    }

    for (auto& p: base_class_objects_) {
        p.second->collect_base_class_object(base_class, result);
    }
}

int* Object::find_legal_member_variable_pointer(const std::string& name,
                                                const Class* qualified_class) {
    Object* target = this;
    if (qualified_class != nullptr) {
        std::set<Object*> object_result;
        collect_base_class_object(qualified_class, &object_result);
        if (object_result.empty() || object_result.size() > 1) {
            return nullptr;
        }

        target = *object_result.begin();
    }

    std::set<int*> pointer_result;
    target->collect_member_variable_pointer(name, &pointer_result);
    if (pointer_result.empty() || pointer_result.size() > 1) {
        return nullptr;
    }

    return *pointer_result.begin();
}

void Object::collect_object_for_delete(std::set<Object*>* objects, bool do_delete) {
    for (auto& p: base_class_objects_) {
        objects->emplace(p.second);
        p.second->collect_object_for_delete(objects);
        p.second->base_class_objects_.clear();
    }

    if (do_delete) {
        for (Object* object: *objects) {
            delete object;
        }
    }
}

bool Object::get_member_variable(const char* name, const Class* qualified_class, int* result) {
    std::string name_str(name);
    int* ptr = find_legal_member_variable_pointer(name, qualified_class);
    if (ptr == nullptr) {
        return false;
    }

    *result = *ptr;
    return true;
}

bool Object::set_member_variable(const char* name, const Class* qualified_class, int value) {
    std::string name_str(name);
    int* ptr = find_legal_member_variable_pointer(name, qualified_class);
    if (ptr == nullptr) {
        return false;
    }

    *ptr = value;
    return true;
}

Object::~Object() {
    std::set<Object*> objects;
    collect_object_for_delete(&objects, true);
}